local function saveSessionFile(token, username)
    local node = xmlLoadFile("@remembered_session.xml")
    if not node then node = xmlCreateFile("@remembered_session.xml", "session") end
    if not node then return end
    xmlNodeSetAttribute(node, "username", tostring(username or ""))
    xmlNodeSetAttribute(node, "token", tostring(token or ""))
    local ok = xmlSaveFile(node)
    xmlUnloadFile(node)
    if not ok then outputDebugString("[LA_STREET_LOGIN] No se pudo guardar remembered_session.xml en el cliente", 1) end
end

local function loadSessionFile()
    local node = xmlLoadFile("@remembered_session.xml")
    if not node then return "", "" end
    local username = xmlNodeGetAttribute(node, "username") or ""
    local token = xmlNodeGetAttribute(node, "token") or ""
    xmlUnloadFile(node)
    return username, token
end

local sx, sy = guiGetScreenSize()
local browser, browserGUI
local ready = false
local function showLogin()
    if isElement(browserGUI) then destroyElement(browserGUI) end
    browserGUI = guiCreateBrowser(0, 0, sx, sy, true, true, false)
    browser = guiGetBrowser(browserGUI)
    addEventHandler("onClientBrowserCreated", browser, function()
        local thisBrowser = source
        addEvent("laLogin:login", true)
        addEvent("laLogin:register", true)
        addEvent("laLogin:autoLogin", true)
        addEvent("laLogin:remember", true)
        addEvent("laLogin:forgetDevice", true)
        addEventHandler("laLogin:forgetDevice", thisBrowser, function()
            saveSessionFile("", "")
        end)
        addEventHandler("laLogin:autoLogin", thisBrowser, function(username, token)
            triggerServerEvent("laLogin:autoLogin", resourceRoot, username, token)
        end)
        addEventHandler("laLogin:remember", thisBrowser, function(enabled)
            triggerServerEvent("laLogin:remember", resourceRoot, enabled)
        end)
        addEventHandler("laLogin:login", thisBrowser, function(username, password, remember)
            triggerServerEvent("laLogin:login", resourceRoot, username, password, remember)
        end)
        addEventHandler("laLogin:register", thisBrowser, function(username, password, remember)
            triggerServerEvent("laLogin:register", resourceRoot, username, password, remember)
        end)
        loadBrowserURL(thisBrowser, "http://mta/local/web/index.html")
    end)
    addEventHandler("onClientBrowserDocumentReady", browser, function()
        ready = true
        local cfg = {
            serverName = LA_LOGIN.serverName, creator = LA_LOGIN.creator,
            owners = LA_LOGIN.owners, collaborators = LA_LOGIN.collaborators,
            logo = "../assets/logo.png", accent = LA_LOGIN.accent,
            accent2 = LA_LOGIN.accent2, background = LA_LOGIN.background,
            youtubeVideoId = LA_LOGIN.youtubeVideoId,
            backgroundImage = LA_LOGIN.backgroundImage,
            showCreatorCredit = LA_LOGIN.showCreatorCredit,
            welcomeVoice = LA_LOGIN.welcomeVoice, welcomeVoiceText = LA_LOGIN.welcomeVoiceText
        }
        local rememberedUser, rememberedToken = loadSessionFile()
        executeBrowserJavascript(source, "window.LA_LOGIN_CONFIG = " .. toJSON(cfg) .. "; window.initLogin && window.initLogin(window.LA_LOGIN_CONFIG," .. toJSON(rememberedUser) .. "," .. toJSON(rememberedToken) .. ");")
    end)
    showCursor(true)
    showChat(false)
    if LA_LOGIN.freezePlayer then toggleAllControls(false, true, false) end
    if LA_LOGIN.camera then
        setCameraMatrix(unpack(LA_LOGIN.camera))
    end
    fadeCamera(true, 1)
end
addEventHandler("onClientResourceStart", resourceRoot, showLogin)
addEvent("laLogin:notify", true)
addEventHandler("laLogin:notify", resourceRoot, function(kind, message)
    if ready and isElement(browser) then
        executeBrowserJavascript(browser, "window.showMessage(" .. toJSON(kind) .. "," .. toJSON(message) .. ")")
    end
end)
addEvent("laLogin:rememberToken", true)
addEventHandler("laLogin:rememberToken", resourceRoot, function(token, username)
    saveSessionFile(token, username)
    if ready and isElement(browser) then
        executeBrowserJavascript(browser, "window.saveRememberToken && window.saveRememberToken(" .. toJSON(token) .. "," .. toJSON(username or "") .. ")")
    end
end)
addEvent("laLogin:rememberInvalid", true)
addEventHandler("laLogin:rememberInvalid", resourceRoot, function()
    saveSessionFile("", "")
    if ready and isElement(browser) then executeBrowserJavascript(browser, "window.clearRememberToken && window.clearRememberToken()") end
end)
addEvent("laLogin:success", true)
addEventHandler("laLogin:success", resourceRoot, function(username)
    if LA_LOGIN.loginWelcomeEnabled ~= false then
        local message = tostring(LA_LOGIN.loginWelcomeMessage or "Usted inició sesión. ¡Bienvenido a La Street One Oficial!")
        message = message:gsub("{usuario}", tostring(username or getPlayerName(localPlayer)))
        local c = LA_LOGIN.loginWelcomeColor or { 180, 90, 255 }
        outputChatBox(message, tonumber(c[1]) or 180, tonumber(c[2]) or 90, tonumber(c[3]) or 255, true)
    end
    if ready and isElement(browser) then
        executeBrowserJavascript(browser, "window.onLoginSuccess && window.onLoginSuccess()")
    end
    setTimer(function()
        if isElement(browserGUI) then destroyElement(browserGUI) end
        browser, browserGUI, ready = nil, nil, false
    end, 1800, 1)
    showCursor(false)
    showChat(true)
    toggleAllControls(true)
    setCameraTarget(localPlayer)
    fadeCamera(true, 1)
end)
addEventHandler("onClientResourceStop", resourceRoot, function()
    showCursor(false); showChat(true); toggleAllControls(true)
end)
