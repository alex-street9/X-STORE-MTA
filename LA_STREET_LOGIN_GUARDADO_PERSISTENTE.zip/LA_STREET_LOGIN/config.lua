-- LA STREET ONE OFICIAL | Configuración general
LA_LOGIN = {
    serverName = "LA STREET ONE OFICIAL",
    creator = "TheFly",
    owners = { "TheFly" },
    collaborators = {},
    logo = "assets/logo.png",
    accent = "#a020f0",
    accent2 = "#6b00c7",
    background = "youtube", -- youtube, image o color
    youtubeVideoId = "jfKfPfyJRdk",
    backgroundImage = "",
    allowRegistration = true,
    maxUsernameLength = 24,
    freezePlayer = true,
    camera = { 1481.0, -1740.0, 80.0, 1481.0, -1740.0, 10.0 },
    -- Punto de aparición después de autenticar. Cámbialo por el spawn de tu servidor.
    spawn = { x = 1481.0, y = -1740.0, z = 13.5, rotation = 0, interior = 0, dimension = 0, skin = 0 },
    showCreatorCredit = true,
    -- Mensaje de chat al iniciar sesión. Puedes editarlo aquí.
    loginWelcomeEnabled = true,
    loginWelcomeMessage = "Usted inició sesión. ¡Bienvenido a La Street One Oficial!",
    loginWelcomeColor = { 180, 90, 255 },
    welcomeVoice = true,
    welcomeVoiceText = "Bienvenido a nuestro server"
}
