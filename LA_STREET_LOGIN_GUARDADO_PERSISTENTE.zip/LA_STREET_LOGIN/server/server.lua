-- LA STREET ONE OFICIAL - Auth SQLite sin permisos ACL
-- Creador: TheFly
local db
local attempts = {}
local busy = {}
local authenticated = {}
local pendingRemember = {}
local migrateVerifiedLegacy

local function notify(player, kind, message)
    if isElement(player) then triggerClientEvent(player, "laLogin:notify", resourceRoot, kind, message) end
end

local function query(sql, callback, ...)
    -- En MTA la conexión debe ser el segundo argumento de dbQuery.
    local args = {...}
    dbQuery(function(qh)
        local rows, err = dbPoll(qh, 0)
        callback(rows, err, unpack(args))
    end, db, sql, unpack(args))
end

local function serverLog(message)
    outputServerLog("[LA_STREET_LOGIN] " .. tostring(message))
end

local function stamp()
    local t = getRealTime()
    return string.format("%04d-%02d-%02d %02d:%02d:%02d", t.year + 1900, t.month + 1, t.monthday, t.hour, t.minute, t.second)
end

local function validUsername(name)
    return type(name) == "string" and #name >= 3 and #name <= (LA_LOGIN.maxUsernameLength or 24)
       and name:match("^[%w_]+$") ~= nil
end

local function validPassword(password)
    -- Sin mínimo ni máximo impuesto por el resource. No aceptar cadena vacía.
    return type(password) == "string" and #password > 0
end

local function throttle(player)
    local now, last = getTickCount(), attempts[player] or 0
    if now - last < 1200 then return false end
    attempts[player] = now
    return true
end

local function issueRememberToken(player, username)
    if not pendingRemember[player] or not db then return end
    local serial = getPlayerSerial(player)
    local token = hash("sha256", tostring(math.random()) .. tostring(getTickCount()) .. tostring(getRealTime().timestamp) .. serial .. tostring(math.random()))
    local digest = hash("sha256", token)
    if dbExec(db, "INSERT OR REPLACE INTO remembered_sessions (username, serial, token_hash) VALUES (?, ?, ?)", username, serial, digest) then
        triggerClientEvent(player, "laLogin:rememberToken", resourceRoot, token, username)
    end
    pendingRemember[player] = nil
end

local function finishLogin(player, username)
    if not isElement(player) then return end
    local sp = LA_LOGIN.spawn or { x = 1481.0, y = -1740.0, z = 13.5, rotation = 0, interior = 0, dimension = 0, skin = 0 }
    spawnPlayer(player, sp.x or 1481, sp.y or -1740, sp.z or 13.5, sp.rotation or 0,
        sp.skin or 0, sp.interior or 0, sp.dimension or 0)
    setElementFrozen(player, false)
    setElementData(player, "laStreet:loggedIn", true, false)
    setElementData(player, "laStreet:username", username, true)
    fadeCamera(player, true, 1.0)
    authenticated[player] = username
    if pendingRemember[player] then
        issueRememberToken(player, username)
    end
    pendingRemember[player] = nil
    triggerClientEvent(player, "laLogin:success", resourceRoot, username)
    serverLog(string.format("[%s] ENTRADA | cuenta=%s | jugador=%s | serial=%s", stamp(), tostring(username), getPlayerName(player), getPlayerSerial(player)))
    triggerEvent("laLogin:onAuthenticated", resourceRoot, player, username)
end

addEventHandler("onResourceStart", resourceRoot, function()
    db = dbConnect("sqlite", ":/la_street_login.db")
    if not db then
        outputDebugString("[LA_STREET_LOGIN] ERROR: no se pudo abrir la base SQLite.", 1)
        return
    end
    dbExec(db, [[CREATE TABLE IF NOT EXISTS accounts (
        username TEXT PRIMARY KEY COLLATE NOCASE,
        serial TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        password_salt TEXT NOT NULL,
        created_at INTEGER NOT NULL
    )]])
    -- Actualizar bases anteriores que impedían más de una cuenta por dispositivo.
    local info = dbPoll(dbQuery(db, "SELECT sql FROM sqlite_master WHERE type='table' AND name='accounts'"), -1)
    if info and info[1] and info[1].sql and info[1].sql:find("serial TEXT NOT NULL UNIQUE", 1, true) then
        dbExec(db, "BEGIN TRANSACTION")
        local a = dbExec(db, [[CREATE TABLE IF NOT EXISTS accounts_new (username TEXT PRIMARY KEY COLLATE NOCASE, serial TEXT NOT NULL, password_hash TEXT NOT NULL, password_salt TEXT NOT NULL, created_at INTEGER NOT NULL)]])
        local b = a and dbExec(db, "INSERT OR IGNORE INTO accounts_new SELECT username, serial, password_hash, password_salt, created_at FROM accounts")
        local c = b and dbExec(db, "DROP TABLE accounts")
        local d = c and dbExec(db, "ALTER TABLE accounts_new RENAME TO accounts")
        if d then dbExec(db, "COMMIT") else dbExec(db, "ROLLBACK"); outputDebugString("[LA_STREET_LOGIN] ERROR migrando base de datos", 1) end
    end
    dbExec(db, [[CREATE TABLE IF NOT EXISTS remembered_sessions (
        username TEXT PRIMARY KEY COLLATE NOCASE,
        serial TEXT NOT NULL,
        token_hash TEXT NOT NULL
    )]])
    outputDebugString("[LA_STREET_LOGIN] Base SQLite lista. No requiere permisos ACL de cuentas MTA.", 3)
end)

addEvent("laLogin:register", true)
addEventHandler("laLogin:register", resourceRoot, function(username, password, remember)
    local player = client
    if not isElement(player) or not throttle(player) or busy[player] then return end
    if not db then return notify(player, "error", "El sistema de cuentas no está disponible. Avísale al staff.") end
    if not LA_LOGIN.allowRegistration then return notify(player, "error", "El registro está desactivado.") end
    if not validUsername(username) then return notify(player, "error", "El usuario debe tener 3-24 letras, números o guion bajo.") end
    if not validPassword(password) then return notify(player, "error", "Escribe una contraseña.") end
    local serial = getPlayerSerial(player)
    if not serial or serial == "" then return notify(player, "error", "No se pudo verificar tu identificador de MTA.") end
    -- Al crear una cuenta, se recuerda automáticamente este dispositivo.
    pendingRemember[player] = true
    busy[player] = true
    query("SELECT username FROM accounts WHERE username=? LIMIT 1", function(rows)
        if not isElement(player) then return end
        if not rows then busy[player] = nil; return notify(player, "error", "Error consultando la base de datos.") end
        if #rows > 0 then
            busy[player] = nil
            return notify(player, "error", "Ese nombre de usuario ya está registrado. Elige otro o inicia sesión.")
        end
        -- Pre-hash SHA-256 con sal aleatoria para que bcrypt no recorte contraseñas largas.
        local salt = hash("sha256", tostring(getTickCount()) .. tostring(math.random()) .. serial .. tostring(getRealTime().timestamp))
        local preHash = hash("sha256", salt .. password)
        passwordHash(preHash, "bcrypt", { cost = 10 }, function(hashed)
            if not isElement(player) then return end
            if not hashed then busy[player] = nil; return notify(player, "error", "No se pudo proteger la contraseña. Inténtalo otra vez.") end
            dbExec(db, "INSERT INTO accounts (username, serial, password_hash, password_salt, created_at) VALUES (?, ?, ?, ?, ?)",
                username, serial, hashed, salt, getRealTime().timestamp)
            query("SELECT username FROM accounts WHERE username=? LIMIT 1", function(checkRows)
                busy[player] = nil
                if not isElement(player) then return end
                if checkRows and #checkRows > 0 then
                    finishLogin(player, checkRows[1].username)
                else
                    notify(player, "error", "No se pudo guardar la cuenta. Inténtalo otra vez.")
                end
            end, username)
        end)
    end, username)
end)

local function migrateLegacyMTAAccount(player, username, password)
    -- Compatibilidad: valida cuentas creadas con el sistema interno de cuentas MTA.
    local legacyAccount = getAccount(username, password)
    if not legacyAccount then
        busy[player] = nil
        return notify(player, "error", "Cuenta no encontrada o contraseña incorrecta. Si la cuenta era del sistema anterior, verifica usuario y contraseña.")
    end

    local serial = getPlayerSerial(player)
    if not serial or serial == "" then
        busy[player] = nil
        return notify(player, "error", "No se pudo verificar tu identificador de MTA.")
    end

    query("SELECT username FROM accounts WHERE serial=? LIMIT 1", function(serialRows)
        if not isElement(player) then return end
        if not serialRows then busy[player] = nil; return notify(player, "error", "Error consultando la base de datos.") end
        -- Una cuenta previa asociada al mismo serial no impide recuperar
        -- una cuenta antigua verificada con contraseña real de MTA.
        local oldName = #serialRows > 0 and serialRows[1].username or nil
        local legacyName = getAccountName(legacyAccount)
        query("SELECT serial FROM accounts WHERE username=? LIMIT 1", function(nameRows)
            if not isElement(player) then return end
            if not nameRows then busy[player] = nil; return notify(player, "error", "Error leyendo la cuenta anterior.") end
            if #nameRows > 0 and nameRows[1].serial ~= serial then
                busy[player] = nil
                return notify(player, "error", "Este usuario pertenece a otro jugador. Contacta al administrador.")
            end
            migrateVerifiedLegacy(player, legacyAccount, legacyName, password, serial, oldName)
        end, legacyName)
    end, serial)
end

-- Se define antes de los eventos para permitir migraciones verificadas.
migrateVerifiedLegacy = function(player, legacyAccount, legacyName, password, serial, oldName)
        local salt = hash("sha256", tostring(getTickCount()) .. tostring(math.random()) .. serial .. tostring(getRealTime().timestamp))
        local preHash = hash("sha256", salt .. password)
        passwordHash(preHash, "bcrypt", { cost = 10 }, function(hashed)
            if not isElement(player) then return end
            if not hashed then busy[player] = nil; return notify(player, "error", "No se pudo migrar la cuenta anterior.") end
            local ok
            if oldName == legacyName then
                ok = dbExec(db, "DELETE FROM remembered_sessions WHERE username=?", legacyName)
                ok = dbExec(db, "DELETE FROM accounts WHERE username=?", legacyName) and ok
            end
            if ok == false then
                busy[player] = nil
                return notify(player, "error", "No se pudo preparar la migración.")
            end
            local inserted = dbExec(db, "INSERT OR REPLACE INTO accounts (username, serial, password_hash, password_salt, created_at) VALUES (?, ?, ?, ?, ?)",
                legacyName, serial, hashed, salt, getRealTime().timestamp)
            if not inserted then
                busy[player] = nil
                return notify(player, "error", "No se pudo guardar la cuenta antigua. Revisa server.log.")
            end
            -- MTA autentica además la cuenta original para conservar permisos ACL.
            if not logIn(player, legacyAccount, password) then
                busy[player] = nil
                return notify(player, "error", "MTA no pudo iniciar tu cuenta original. Comprueba que no esté abierta en otro jugador.")
            end
            busy[player] = nil
            finishLogin(player, legacyName)
            serverLog("Cuenta antigua de MTA recuperada: " .. legacyName)
        end)
end

addEvent("laLogin:login", true)
addEventHandler("laLogin:login", resourceRoot, function(username, password, remember)
    local player = client
    if not isElement(player) or not throttle(player) or busy[player] then return end
    if not validUsername(username) or not validPassword(password) then
        return notify(player, "error", "Completa el usuario y la contraseña.")
    end
    if not db then return notify(player, "error", "El sistema de cuentas no está disponible.") end
    pendingRemember[player] = remember == true
    busy[player] = true
    query("SELECT username, serial, password_hash, password_salt FROM accounts WHERE username=? LIMIT 1", function(rows)
        if not isElement(player) then return end
        if not rows then
            busy[player] = nil
            return notify(player, "error", "Error leyendo las cuentas guardadas. Revisa el log del servidor.")
        end
        if #rows == 0 then
            return migrateLegacyMTAAccount(player, username, password)
        end
        local row = rows[1]
        local preHash = hash("sha256", row.password_salt .. password)
        passwordVerify(preHash, row.password_hash, {}, function(ok)
            if not isElement(player) then return end
            busy[player] = nil
            if not ok then
                busy[player] = true
                return migrateLegacyMTAAccount(player, username, password)
            end
            local serial = getPlayerSerial(player)
            if row.serial ~= serial then
                dbExec(db, "UPDATE accounts SET serial=? WHERE username=?", serial, row.username)
                dbExec(db, "DELETE FROM remembered_sessions WHERE username=?", row.username)
            end
            -- El panel admin (/admin, P) comprueba getPlayerAccount y ACL de MTA.
            -- Una sesión SQLite sola NO concede esos permisos.
            local nativeAccount = getAccount(row.username)
            if nativeAccount then
                local verifiedNative = getAccount(row.username, password)
                if not verifiedNative then
                    return notify(player, "error", "Esta cuenta existe en MTA, pero su contraseña original es diferente. Usa la contraseña de tu cuenta administradora.")
                end
                if not logIn(player, verifiedNative, password) then
                    return notify(player, "error", "No se pudo activar la cuenta de MTA. Comprueba que no esté conectada en otro jugador.")
                end
            end
            finishLogin(player, row.username)
        end)
    end, username)
end)

addEventHandler("onPlayerQuit", root, function(reason)
    local player = source
    if getElementData(player, "laStreet:loggedIn") then
        local username = getElementData(player, "laStreet:username") or "desconocido"
        serverLog(string.format("[%s] SALIDA | cuenta=%s | jugador=%s | serial=%s | motivo=%s", stamp(), tostring(username), getPlayerName(player), getPlayerSerial(player), tostring(reason or "desconocido")))
    end
    attempts[player], busy[player], authenticated[player], pendingRemember[player] = nil, nil, nil, nil
end)

-- La contraseña nunca se guarda en el navegador. El token solo se entrega
-- después de una autenticación correcta y se valida junto con el serial.
addEvent("laLogin:remember", true)
addEventHandler("laLogin:remember", resourceRoot, function(enabled)
    local player = client
    if not isElement(player) or not authenticated[player] or not db then return end
    local username = authenticated[player]
    if enabled ~= true then
        dbExec(db, "DELETE FROM remembered_sessions WHERE username=?", username)
        triggerClientEvent(player, "laLogin:rememberToken", resourceRoot, "")
        return
    end
    local token = hash("sha256", tostring(math.random()) .. tostring(getTickCount()) .. tostring(getRealTime().timestamp) .. getPlayerSerial(player) .. tostring(math.random()))
    local digest = hash("sha256", token)
    dbExec(db, "INSERT OR REPLACE INTO remembered_sessions (username, serial, token_hash) VALUES (?, ?, ?)", username, getPlayerSerial(player), digest)
    triggerClientEvent(player, "laLogin:rememberToken", resourceRoot, token, username)
end)

addEvent("laLogin:autoLogin", true)
addEventHandler("laLogin:autoLogin", resourceRoot, function(username, token)
    local player = client
    if not isElement(player) or busy[player] or authenticated[player] or not db then return end
    if not validUsername(username) or type(token) ~= "string" or not token:match("^[a-fA-F0-9]+$") or #token ~= 64 then return end
    busy[player] = true
    query("SELECT a.username FROM remembered_sessions s JOIN accounts a ON a.username=s.username WHERE s.username=? AND s.serial=? AND s.token_hash=? AND a.serial=? LIMIT 1", function(rows)
        busy[player] = nil
        if not isElement(player) then return end
        if rows and #rows > 0 then
            -- Para cuentas ACL de MTA se conserva el usuario precargado, pero se exige
            -- contraseña original: nunca se conceden permisos admin por token SQLite.
            if getAccount(rows[1].username) then
                notify(player, "info", "Tu cuenta está recordada. Escribe tu contraseña original de MTA para activar el panel administrador.")
                return
            end
            finishLogin(player, rows[1].username)
        else
            triggerClientEvent(player, "laLogin:rememberInvalid", resourceRoot)
        end
    end, username, getPlayerSerial(player), hash("sha256", token), getPlayerSerial(player))
end)
