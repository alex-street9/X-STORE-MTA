(function(){
  function el(id){return document.getElementById(id)}
  var voicePlayed=false;
  function speakWelcome(text){
    if(voicePlayed || !('speechSynthesis' in window) || !window.LA_LOGIN_CONFIG || window.LA_LOGIN_CONFIG.welcomeVoice===false) return;
    voicePlayed=true;
    try {
      window.speechSynthesis.cancel();
      var utterance=new SpeechSynthesisUtterance(text||'Bienvenido a nuestro server');
      utterance.lang='es-ES'; utterance.rate=0.88; utterance.pitch=0.92; utterance.volume=0.9;
      window.speechSynthesis.speak(utterance);
    } catch(e) {}
  }
  window.initLogin=function(cfg,storedUser,storedToken){
    window.LA_LOGIN_CONFIG=cfg;
    el('server-name').textContent=cfg.serverName||'LA STREET ONE OFICIAL';
    el('server-logo').src=cfg.logo||'../assets/logo.png';
    el('creator-credit').style.display=cfg.showCreatorCredit===false?'none':'block';
    el('creator-credit').innerHTML='SISTEMA CREADO POR <b>'+(cfg.creator||'TheFly')+'</b>';
    var owners=(cfg.owners||[]).filter(Boolean), collabs=(cfg.collaborators||[]).filter(Boolean);
    var lines=[]; if(owners.length)lines.push('DUEÑO: '+owners.join(' • ')); if(collabs.length)lines.push('COLABORADORES: '+collabs.join(' • '));
    el('credits').innerHTML=lines.map(function(x){return '<div>'+escapeHTML(x)+'</div>'}).join('');
    document.documentElement.style.setProperty('--accent',cfg.accent||'#a020f0');
    document.documentElement.style.setProperty('--accent2',cfg.accent2||'#6b00c7');
    if(cfg.background==='youtube'&&cfg.youtubeVideoId){
      var iframe=document.createElement('iframe'); iframe.src='https://www.youtube-nocookie.com/embed/'+encodeURIComponent(cfg.youtubeVideoId)+'?autoplay=1&mute=1&controls=0&loop=1&playlist='+encodeURIComponent(cfg.youtubeVideoId)+'&playsinline=1&modestbranding=1&rel=0';
      iframe.allow='autoplay; encrypted-media'; iframe.frameBorder='0'; el('youtube-wrap').appendChild(iframe);
    }else if(cfg.background==='image'&&cfg.backgroundImage){el('background').style.backgroundImage='url("'+String(cfg.backgroundImage).replace(/"/g,'')+'")';el('background').style.backgroundSize='cover';el('background').style.backgroundPosition='center'}
    // Casilla desmarcada por defecto. Solo una sesión local válida permite marcarla.
    el('remember-me').checked=false;
    try {
      var token=storedToken || '';
      var savedUser=storedUser || '';
      if (!savedUser) savedUser=localStorage.getItem('laStreetRememberedUser') || '';
      if (!token) token=localStorage.getItem('laStreetRememberToken') || '';
      if (savedUser) el('login-user').value=savedUser;
      if(token && savedUser){
        el('login-user').value=savedUser;
        el('remember-me').checked=true;
        if(window.mta){showMessage('info','Comprobando sesión recordada...');window.mta.triggerEvent('laLogin:autoLogin',savedUser,token)}
      }
    } catch(e) {}
    speakWelcome(cfg.welcomeVoiceText||'Bienvenido a nuestro server');
  };
  function escapeHTML(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  window.showMessage=function(kind,msg){el('message').textContent=msg;el('message').style.color=kind==='error'?'#ff9bba':'#d9a7ff'};
  document.querySelectorAll('.tab').forEach(function(btn){btn.addEventListener('click',function(){document.querySelectorAll('.tab').forEach(function(b){b.classList.remove('active')});btn.classList.add('active');var reg=btn.dataset.view==='register';el('login-form').classList.toggle('hidden',reg);el('register-form').classList.toggle('hidden',!reg);el('message').textContent=''})});
  window.saveRememberToken=function(token,username){
    if(!token) el('remember-me').checked=false;
    try {
      if(token){el('remember-me').checked=true;el('login-user').value=username;localStorage.setItem('laStreetRememberToken',token);localStorage.setItem('laStreetRememberedUser',username)}
      else {localStorage.removeItem('laStreetRememberToken');localStorage.removeItem('laStreetRememberedUser')}
    }catch(e){}
  };
  window.clearRememberToken=function(){window.saveRememberToken('','');el('remember-me').checked=false;showMessage('error','La sesión guardada ya no es válida. Entra con tu contraseña.')};
  window.onLoginSuccess=function(){};
  el('login-form').addEventListener('submit',function(e){e.preventDefault();var user=el('login-user').value.trim();try{if(!el('remember-me').checked){localStorage.removeItem('laStreetRememberedUser');localStorage.removeItem('laStreetRememberToken')}}catch(err){} if(window.mta)window.mta.triggerEvent('laLogin:login',user,el('login-pass').value,el('remember-me').checked);else showMessage('error','Abre este panel desde el servidor MTA.')});
  el('remember-me').addEventListener('change',function(){if(!this.checked){try{localStorage.removeItem('laStreetRememberedUser');localStorage.removeItem('laStreetRememberToken')}catch(e){} if(window.mta)window.mta.triggerEvent('laLogin:forgetDevice');}});
  el('register-form').addEventListener('submit',function(e){e.preventDefault();var user=el('register-user').value.trim();if(window.mta)window.mta.triggerEvent('laLogin:register',user,el('register-pass').value,true);else showMessage('error','Abre este panel desde el servidor MTA.')});
  // Algunos CEF bloquean voz automática hasta la primera interacción del usuario.
  document.addEventListener('click',function(){if(!voicePlayed && window.LA_LOGIN_CONFIG) speakWelcome(window.LA_LOGIN_CONFIG.welcomeVoiceText);},{once:true});
})();
