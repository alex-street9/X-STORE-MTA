LA STREET ONE OFICIAL - LOGIN MTA:SA
Versión 2.0.0 | Creador: TheFly

CAMBIOS DE ESTA VERSION
- Registro e inicio de sesión para todos los jugadores sin agregar el resource a ACL.
- Cuentas guardadas en una base SQLite propia del resource.
- Una cuenta por serial de MTA.
- El login recuerda el nombre de usuario en el PC del jugador (no guarda la contraseña).
- Contraseña sin mínimo ni máximo impuesto por el formulario o el script. Se procesa con SHA-256 + bcrypt.
- Voz de bienvenida: “Bienvenido a nuestro server” (si el CEF del jugador tiene Speech Synthesis disponible).
- Interfaz rediseñada con estilo cinematográfico/urbano morado.
- Aparición automática al autenticarse, en las coordenadas configuradas.

REQUISITO
Esta versión requiere MTA:SA 1.6.0 o superior por las funciones modernas de hash seguro passwordHash/passwordVerify.

INSTALACIÓN
1. Haz una copia de seguridad de tu resource/login anterior.
2. Copia la carpeta LA_STREET_LOGIN dentro de server/mods/deathmatch/resources/.
3. En la consola del servidor ejecuta: refresh
4. Ejecuta: start LA_STREET_LOGIN
5. Para iniciarlo automáticamente, agrega a mtaserver.conf:
   <resource src="LA_STREET_LOGIN" startup="1" />

ACL
No necesita agregar LA_STREET_LOGIN a Admin ni conceder function.addAccount, function.getAccount o function.logIn.
El resource usa SQLite propio y no crea ni inicia sesión en cuentas internas de MTA. Por eso los jugadores normales pueden registrarse sin permisos ACL.

IMPORTANTE SOBRE CUENTAS ANTERIORES
Las cuentas creadas anteriormente en el sistema interno de MTA no se importan automáticamente a esta base SQLite. Los jugadores antiguos deberán contactar al staff para migración o crear su cuenta en este nuevo sistema. El nombre recordado se guarda localmente en el PC del jugador después de escribirlo; nunca se guarda la contraseña.

UNA CUENTA POR JUGADOR
El sistema vincula la cuenta al serial de MTA. Un serial puede registrar una sola cuenta. Esto no identifica a una persona física y no evita que alguien use otro serial.

CONTRASEÑAS
No se impone una longitud máxima desde la interfaz ni desde el código del resource. La contraseña se pre-procesa con SHA-256 y luego se protege con bcrypt y sal. Se recomienda usar una contraseña larga y difícil de adivinar.

CONFIGURACIÓN
Edita config.lua:
- serverName: nombre del servidor.
- creator: creador mostrado (TheFly).
- owners / collaborators: créditos.
- accent / accent2: colores.
- background: youtube, image o color.
- youtubeVideoId: ID de video YouTube (no pegues la URL completa).
- backgroundImage: URL o ruta local para modo image.
- allowRegistration: activar/desactivar registros.
- camera: posición de cámara inicial mientras aparece el login.
- spawn: posición de aparición después del login (x, y, z, rotation, interior, dimension, skin).
- welcomeVoice: activar/desactivar voz.
- welcomeVoiceText: frase de bienvenida.

VOZ Y VIDEO
La voz utiliza Speech Synthesis del navegador CEF. Algunos equipos/versiones de CEF no incluyen voces instaladas o bloquean voz automática; en esos casos el login seguirá funcionando, pero no se oirá la frase. El video de YouTube también depende de que el video permita inserción y de la compatibilidad de CEF.

INTEGRACIÓN CON OTROS SISTEMAS
Al autenticarse, el servidor dispara el evento:
   laLogin:onAuthenticated
con source=resourceRoot y argumentos (player, username).
También establece element data:
   laStreet:loggedIn = true
   laStreet:username = nombre de usuario
Otros recursos de spawn/personaje pueden escuchar ese evento si quieres integrar tu sistema existente.

PRUEBAS
Prueba primero en un servidor de desarrollo. Confirma que la ubicación de spawn en config.lua sea la correcta para tu mapa y que no choque con otro sistema de login/spawn.


ACTUALIZACION: REGISTRO, SPAWN Y RECORDARME
- Al completar el registro, el jugador inicia sesion automaticamente y aparece en el punto configurado en config.lua (LA_LOGIN.spawn).
- El servidor escribe en el log una línea ENTRADA cuando la cuenta se autentica y una línea SALIDA cuando ese jugador sale. Incluye fecha/hora, cuenta, nick, serial y motivo de salida.
- Las cuentas se guardan en SQLite del servidor y permanecen aunque el jugador cierre el juego o salga del servidor.
- La casilla RECORDARME EN ESTE DISPOSITIVO guarda solamente el nombre de usuario en el almacenamiento local de CEF. No guarda la contraseña.
- Si se desmarca, se elimina el nombre guardado. La contraseña debe escribirse por seguridad cada vez.
- Para cambiar el lugar de aparicion, edita LA_LOGIN.spawn en config.lua.


LOG DE ENTRADAS Y SALIDAS
Busca [LA_STREET_LOGIN] en el archivo logs/server.log del servidor. Se registran ENTRADA y SALIDA de jugadores autenticados. Las conexiones que abandonen antes de iniciar sesión no se registran como entrada de cuenta.

ACTUALIZACION: Recuperacion de cuenta MTA verificada por contrasena aun si ya hay cuenta SQLite del mismo serial. La cuenta anterior SQLite se sustituye SOLO tras validar la clave de la cuenta MTA. Realiza backup de la DB antes de instalar. Recordar en este dispositivo: al iniciar correctamente genera token de sesion, guardado en localStorage, y permite inicio automatico en el mismo equipo. No guarda contrasena. No borres datos de navegador CEF ni DB. Se registra ENTRADA y SALIDA en server.log. Si la cuenta antigua procede de un sistema personalizado, se requiere integracion adicional.

MENSAJE DE BIENVENIDA AL INICIAR SESION
Edita config.lua: loginWelcomeMessage para cambiar el texto.
loginWelcomeEnabled = false para ocultarlo.
loginWelcomeColor = { 180, 90, 255 } para cambiar color RGB.
Puedes escribir {usuario} dentro del mensaje para mostrar el usuario autenticado.

RECORDARME: Se conserva el usuario y un token de sesion en el archivo privado @remembered_session.xml del cliente. La contrasena NO se almacena. La cuenta administradora nativa de MTA debe introducir su contrasena para activar ACL en cada sesion: un token de SQLite no puede sustituir logIn de MTA. No borrar la base SQLite del servidor.

REGISTRO AUTOMATICO: al crear una cuenta se guarda una sesion recordada en este dispositivo, y en siguientes conexiones se intenta entrar sin pedir datos. Para desactivar el recordatorio, desmarca la casilla al iniciar sesion. Las cuentas MTA con ACL pueden requerir la contrasena original para activar permisos de administrador.
